
fetch('https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js').then(() => {
  document.querySelector('#printableArea').remove();
  document.querySelector('body').style.overflow="visible";
})
.catch(() => {
  document.getElementsByClassName('message')[0].innerHTML = 'Please Disable Adblock!';
});

if(document.querySelectorAll('[id*="printableArea"]')){
  document.querySelector('body').style.overflow="hidden";
}